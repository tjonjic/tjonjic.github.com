/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.Arrays;
import java.util.Set;
import java.util.NavigableSet;
import java.util.Map;
import java.util.HashSet;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.Collections;
import java.util.List;
import java.util.LinkedList;

/**
 * Represents a combat situation, and provides a programmatic way to
 * resolve it.
 */
public class CombatSequence {

    /**
     * A phase in the combat sequence.
     */
    public enum CombatPhase {
        PROLOGUE,
        AWAITING_ATTACKER_FIRE,
        AWAITING_DEFENDER_FIRE,
        AWAITING_ATTACKER_CASUALTIES_REMOVAL,
        AWAITING_DEFENDER_CASUALTIES_REMOVAL,
        END_OF_ROUND,
        TERMINATED
    }

    private interface State {
        void start();
        void addAttacker(TerritoryUnit unit);
        void attack();
        void defend();
        void removeAttackerCasualties(Set<TerritoryUnit> units);
        void removeDefenderCasualties(Set<TerritoryUnit> units);
        void startRound();
        void retreat();
        boolean succeeded();
    }

    private class StubStateImpl implements State {
        public void start() {
            throw new UnsupportedOperationException();
        }

        public void addAttacker(TerritoryUnit unit) {
            throw new UnsupportedOperationException();
        }

        public void attack() {
            throw new UnsupportedOperationException();
        }

        public int[] attackFireOutcome() {
            throw new UnsupportedOperationException();
        }

        public void defend() {
            throw new UnsupportedOperationException();
        }

        public int[] defenseFireOutcome() {
            throw new UnsupportedOperationException();
        }

        public void removeAttackerCasualties(Set<TerritoryUnit> units) {
            throw new UnsupportedOperationException();
        }

        public void removeDefenderCasualties(Set<TerritoryUnit> units) {
            throw new UnsupportedOperationException();
        }

        public void startRound() {
            throw new UnsupportedOperationException();
        }

        public void retreat() {
            throw new UnsupportedOperationException();
        }

        public boolean succeeded() {
            throw new UnsupportedOperationException();
        }
    }

    private class PrologueState extends StubStateImpl {
        public void start() {
            attackerFireOutcome = new int[attackerLevels.size()];
            defenderFireOutcome = new int[defenderLevels.size()];
            setPhase(CombatPhase.AWAITING_ATTACKER_FIRE);
        }

        public void addAttacker(TerritoryUnit unit) {
            int attackCap = unit.attackCapability();

            if (!attackerLevels.contains(attackCap))
                attackerLevels.add(attackCap);

            if (!attackers.containsKey(attackCap))
                attackers.put(attackCap, new HashSet<TerritoryUnit>());

            attackers.get(attackCap).add(unit);
        }
    }

    private class AttackState extends StubStateImpl {
        public void attack() {
            defenderCasualties = 0;

            int index = 0;
            for (int level : attackerLevels) {
                int units = attackers.get(level).size();
                int hits = 0;
                for (int roll = 0; roll < units; ++roll) {
                    int outcome = rnp.number();
                    if (outcome <= level)
                        hits++;
                }
                attackerFireOutcome[index++] = hits;
                defenderCasualties += hits;
            }

            setPhase(CombatPhase.AWAITING_DEFENDER_FIRE);
        }
    }

    private class DefendState extends StubStateImpl {
        public void defend() {
            attackerCasualties = 0;

            int index = 0;
            for (int level : defenderLevels) {
                int units = defenders.get(level).size();
                int hitrate = 0;
                for (int roll = 0; roll < units; ++roll) {
                    int outcome = rnp.number();
                    if (outcome <= level)
                        hitrate++;
                }
                defenderFireOutcome[index++] = hitrate;
                attackerCasualties += hitrate;
            }

            if (attackerCasualties > 0)
                setPhase(CombatPhase.AWAITING_ATTACKER_CASUALTIES_REMOVAL);
            else if (defenderCasualties > 0)
                setPhase(CombatPhase.AWAITING_DEFENDER_CASUALTIES_REMOVAL);
            else
                setPhase(CombatPhase.END_OF_ROUND);
        }
    }

    private class AttackerCasualtiesState extends StubStateImpl {
        public void removeAttackerCasualties(Set<TerritoryUnit> units) {
            if (units.size() < attackerCasualties &&
                units.size() < attackerCount())
                throw new IllegalArgumentException();

            for (TerritoryUnit unit : units)
                if (!attackers.get(unit.attackCapability()).remove(unit))
                    throw new IllegalArgumentException("unit not found");

            if (attackerDefeated() && defenderCasualties == 0)
                setPhase(CombatPhase.TERMINATED);
            else
                setPhase(CombatPhase.AWAITING_DEFENDER_CASUALTIES_REMOVAL);
        }
    }

    private class DefenderCasualtiesState extends StubStateImpl {
        public void removeDefenderCasualties(Set<TerritoryUnit> units) {
            if (units.size() < defenderCasualties &&
                units.size() < defenderCount())
                throw new IllegalArgumentException();

            for (TerritoryUnit unit : units)
                if (!defenders.get(unit.defenseCapability()).remove(unit))
                    throw new IllegalArgumentException("unit not found");

            if (attackerDefeated() || defenderDefeated())
                setPhase(CombatPhase.TERMINATED);
            else
                setPhase(CombatPhase.END_OF_ROUND);
        }
    }

    private class EndOfRoundState extends StubStateImpl {
        public void startRound() {
            setPhase(CombatPhase.AWAITING_ATTACKER_FIRE);
        }

        public void retreat() {
            setPhase(CombatPhase.TERMINATED);
        }
    }

    private class TerminatedState extends StubStateImpl {
        public boolean succeeded() {
            return !attackerDefeated() && defenderDefeated();
        }
    }

    private List<CombatSequenceListener> listeners;
    private Territory territory;
    private CombatPhase phase;
    private State[] state;
    private RandomNumberProvider rnp;
    private NavigableSet<Integer> attackerLevels;
    private NavigableSet<Integer> defenderLevels;
    private Map<Integer, Set<TerritoryUnit>> attackers;
    private Map<Integer, Set<TerritoryUnit>> defenders;
    private int defenderCasualties;
    private int attackerCasualties;
    private int[] attackerFireOutcome;
    private int[] defenderFireOutcome;

    public CombatSequence(Territory territory) {
        this.territory = territory;
        phase = CombatPhase.PROLOGUE;

        state = new State[] {
            new PrologueState(),
            new AttackState(),
            new DefendState(),
            new AttackerCasualtiesState(),
            new DefenderCasualtiesState(),
            new EndOfRoundState(),
            new TerminatedState()
        };

        attackerLevels = new TreeSet<Integer>();
        defenderLevels = new TreeSet<Integer>();
        attackers = new HashMap<Integer, Set<TerritoryUnit>>();
        defenders = new HashMap<Integer, Set<TerritoryUnit>>();

        for (TerritoryUnit unit : territory) {
            if (unit.hasDefenseAbility()) {
                int defenseCap = unit.defenseCapability();

                if (!defenderLevels.contains(defenseCap))
                    defenderLevels.add(defenseCap);

                if (!defenders.containsKey(defenseCap))
                    defenders.put(defenseCap, new HashSet<TerritoryUnit>());

                defenders.get(defenseCap).add(unit);
            }
        }

        listeners = new LinkedList<CombatSequenceListener>();

        rnp = new SimpleRNP();
    }

    public void addListener(CombatSequenceListener listener) {
        listeners.add(listener);
    }

    private void setPhase(CombatPhase newPhase) {
        phase = newPhase;
        for (CombatSequenceListener listener : listeners)
            listener.combatPhaseChanged();
    }

    private boolean attackerDefeated() {
        for (Set<TerritoryUnit> set : attackers.values())
            if (!set.isEmpty())
                return false;

        return true;
    }

    private boolean defenderDefeated() {
        for (Set<TerritoryUnit> set : defenders.values())
            if (!set.isEmpty())
                return false;

        return true;
    }

    private int attackerCount() {
        int count = 0;
        for (Set<TerritoryUnit> set : attackers.values())
            count += set.size();
        return count;
    }

    private int defenderCount() {
        int count = 0;
        for (Set<TerritoryUnit> set : defenders.values())
            count += set.size();
        return count;
    }

    public boolean terminated() {
        return phase == CombatPhase.TERMINATED;
    }

    public CombatPhase phase() {
        return phase;
    }

    public int[] attackerFireOutcome() {
        return Arrays.copyOf(attackerFireOutcome, attackerFireOutcome.length);
    }

    public int[] defenderFireOutcome() {
        return Arrays.copyOf(defenderFireOutcome, defenderFireOutcome.length);
    }

    public int attackerCasualties() {
        return attackerCasualties;
    }

    public int defenderCasualties() {
        return defenderCasualties;
    }

    public int[] attackerLevels() {
        int[] result = new int[attackerLevels.size()];
        int index = 0;
        for (int level : attackerLevels)
            result[index++] = level;
        return result;
    }

    public Set<TerritoryUnit> attackers(int level) {
        return Collections.unmodifiableSet(attackers.get(level));
    }

    public Set<TerritoryUnit> attackers() {
        Set<TerritoryUnit> result = new HashSet<TerritoryUnit>();

        for (int level : attackerLevels)
            result.addAll(attackers.get(level));

        return result;
    }

    public int[] defenderLevels() {
        int[] result = new int[defenderLevels.size()];
        int index = 0;
        for (int level : defenderLevels)
            result[index++] = level;
        return result;
    }

    public Set<TerritoryUnit> defenders(int level) {
        return Collections.unmodifiableSet(defenders.get(level));
    }

    public Set<TerritoryUnit> defenders() {
        Set<TerritoryUnit> result = new HashSet<TerritoryUnit>();

        for (int level : defenderLevels)
            result.addAll(defenders.get(level));

        return result;
    }

    public void start() {
        state[phase.ordinal()].start();
    }

    public void addAttacker(TerritoryUnit unit) {
        state[phase.ordinal()].addAttacker(unit);
    }

    public void attack() {
        state[phase.ordinal()].attack();
    }

    public void defend() {
        state[phase.ordinal()].defend();
    }

    public void removeAttackerCasualties(Set<TerritoryUnit> units) {
        state[phase.ordinal()].removeAttackerCasualties(units);
    }

    public void removeDefenderCasualties(Set<TerritoryUnit> units) {
        state[phase.ordinal()].removeDefenderCasualties(units);
    }

    public void startRound() {
        state[phase.ordinal()].startRound();
    }

    public void retreat() {
        state[phase.ordinal()].retreat(); 
    }

    public boolean succeeded() {
        return state[phase.ordinal()].succeeded();
    }

}
