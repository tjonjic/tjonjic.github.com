/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

/**
 * Base class for all units.
 */
public abstract class TerritoryUnit {
    private Territory territory;
    private Player owner;
    private TransportUnit parent;

    public TerritoryUnit(Player owner) {
        this.owner = owner;
        this.parent = null;
        this.territory = null;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

    public void setTerritory(Territory territory) {
        this.territory = territory;
    }

    public Territory getTerritory() {
        return territory;
    }

    public void setParent(TransportUnit parent) {
        this.parent = parent;
    }

    public TransportUnit getParent() {
        return parent;
    }

    public boolean hasParent() {
        return getParent() != null;
    }

    /**
     * Get the unit's cannonical name.
     */
    public abstract String name();

    /**
     * Creates another instance of the object's class.
     */
    public abstract TerritoryUnit copy();

    /**
     * Returns true if the unit can be destroyed.
     */
    public abstract boolean isDestroyable();

    /**
     * Checks whether the unit can move to the supplied Territory.
     */
    public abstract boolean canMoveTo(Territory territory);

    public abstract boolean canAttack(Territory territory);

    public abstract boolean canConquer(Territory territory);

    public abstract int cost();

    // Query a units capability

    /**
     * Check wheter a unit can move.
     */
    public abstract boolean hasMovementAbility();

    /**
     * The number of territories the unit can move in a single turn.
     *
     * @return the number of territories the unit can move in a single turn.
     */
    public abstract int movementCapability();

    /**
     * Check wheter a unit has firing (attack) capability.
     */
    public abstract boolean hasAttackAbility();

    /**
     * The unit's attack capability is the greatest number a player
     * can roll for the attack to succeed.
     *
     * @return the unit's attack capability.
     */
    public abstract int attackCapability();

    /**
     * Check wheter a unit has firing (defense) capability.
     */
    public abstract boolean hasDefenseAbility();

    /**
     * @return the number of FIXME
     */
    public abstract int defenseCapability();

    public abstract Object accept(UnitVisitor visitor);
}
