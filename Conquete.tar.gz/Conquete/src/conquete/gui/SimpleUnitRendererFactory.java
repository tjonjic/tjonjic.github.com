/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete.gui;

import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Rectangle;

import conquete.*;

public class SimpleUnitRendererFactory implements UnitRendererFactory {

    private static UnitRenderer basicRenderer = new UnitRenderer()
        {
            private final Color OUTLINE_COLOR = Color.black;

            public void render(TerritoryUnit unit, Graphics2D graphics2d, Rectangle allocation) {
                Graphics2D gc = (Graphics2D) graphics2d.create();
                
                gc.setColor(OUTLINE_COLOR);
                gc.drawRect(allocation.x, allocation.y, allocation.width, allocation.height);
                
                gc.clipRect(allocation.x, allocation.y, allocation.width, allocation.height);
                gc.drawString(unit.name(),
                              allocation.x + allocation.width / 9,
                              allocation.y + allocation.height);
                
                gc.dispose();
            }
        };

    public UnitRenderer createBattleshipUnitRenderer() {
        return basicRenderer;
    }

    public UnitRenderer createBomberAircraftUnitRenderer() {
        return basicRenderer;
    }

    public UnitRenderer createFighterAircraftUnitRenderer() {
        return basicRenderer;
    }

    public UnitRenderer createIndustryUnitRenderer() {
        return basicRenderer;
    }

    public UnitRenderer createInfantryUnitRenderer() {
        return basicRenderer;
    }

    public UnitRenderer createTankUnitRenderer() {
        return basicRenderer;
    }

    public UnitRenderer createTransportShipUnitRenderer() {
        return basicRenderer;
    }

}
