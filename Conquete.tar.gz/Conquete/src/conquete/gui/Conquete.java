/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete.gui;

import java.io.File;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.Action;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.WindowConstants;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import javax.swing.border.BevelBorder;

import conquete.*;

class ApplicationFrame extends JFrame implements GameListener, BoardViewListener {
    private static final String FRAME_TITLE = "Conquete";

    private Appl appl;
    private JScrollPane boardViewScroller;
    private BoardView boardView;
    private JPanel statusBar;
    private JLabel statusLabel;
    private LinkedList<TerritoryUnit> purchasedUnitsBuffer;

    class QuitAction extends AbstractAction {
        public QuitAction(Integer mnemonic) {
            super("Quit");
            putValue(SHORT_DESCRIPTION, "Quit");
            putValue(MNEMONIC_KEY, mnemonic);
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control Q"));
        }

        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    private Action quitAction = new QuitAction(new Integer(KeyEvent.VK_Q));

    class NewGameAction extends AbstractAction {
        private Component parentComponent;
        private GameListener listener;

        public NewGameAction(Component parentComponent, GameListener listener) {
            super("New Game");
            putValue(SHORT_DESCRIPTION, "Start a new game");
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_N));
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
            this.listener = listener;
            this.parentComponent = parentComponent;
        }

        public void actionPerformed(ActionEvent event) {
            JFileChooser fc = new JFileChooser();
            int fcCode = fc.showOpenDialog(parentComponent);

            if (fcCode == JFileChooser.APPROVE_OPTION) {
                File boardFile = fc.getSelectedFile();
                try {
                    appl.newGame(boardFile);
                    boardView.setBoard(appl.getBoard());
                    updateUISensitivity();
                    updateStatus();
                    appl.getGame().addListener(listener);
                    appl.getGame().start();
                } catch (Exception e) {
                    String message = String.format("Cannot load `%s': missing or invalid file",
                                                   boardFile.getName());
                    JOptionPane.showMessageDialog(parentComponent, message, "Error",
                                                  JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private Action newGameAction = new NewGameAction(this, this);

    class EndPhaseAction extends AbstractAction {
        public EndPhaseAction() {
            super("End Movements");
            putValue(SHORT_DESCRIPTION, "End Movements");
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_E));
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E"));
        }

        public void actionPerformed(ActionEvent event) {
            appl.getGame().endPhase();
        }
    }

    private Action endPhaseAction = new EndPhaseAction();

    class StartCombatAction extends AbstractAction {
        public StartCombatAction() {
            super("Start Combat");
            putValue(SHORT_DESCRIPTION, "Start Combat");
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_S));
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
        }

        public void actionPerformed(ActionEvent event) {
            appl.getGame().startCombat();
        }
    }

    private Action startCombatAction = new StartCombatAction();

    public ApplicationFrame() {
        super(FRAME_TITLE);

        appl = Appl.instance();
        
        JPanel panel = new JPanel(new BorderLayout());

        JScrollPane scroller = new JScrollPane();
        boardView = new BoardView();
        boardView.addListener(this);
        scroller.getViewport().add(boardView);

        panel.add(scroller, BorderLayout.CENTER);

        statusBar = new JPanel();
        statusBar.setLayout(new BorderLayout());
        statusBar.setBorder(new BevelBorder(BevelBorder.LOWERED));
        statusLabel = new JLabel("");
        statusBar.add(statusLabel, BorderLayout.CENTER);
        panel.add(statusBar, BorderLayout.SOUTH);

        add(panel);

        createMenuBar();

        setSize(700, 500);
        updateStatus();
        updateUISensitivity();
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu gameMenu = new JMenu("Game");
        gameMenu.setMnemonic('g');
        menuBar.add(gameMenu);
        JMenuItem newGameMenuItem = new JMenuItem(newGameAction);
        newGameMenuItem.setIcon(null);
        gameMenu.add(newGameMenuItem);
        JMenuItem endPhaseMenuItem = new JMenuItem(endPhaseAction);
        endPhaseMenuItem.setIcon(null);
        gameMenu.add(endPhaseMenuItem);
        JMenuItem startCombatMenuItem = new JMenuItem(startCombatAction);
        startCombatMenuItem.setIcon(null);
        gameMenu.add(startCombatMenuItem);
        JMenuItem quitMenuItem = gameMenu.add(new JMenuItem(quitAction));

        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('h');
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);
    }

    private void updateStatus() {
        Game game = appl.getGame();

        if (game != null) {
            if (game.isOver())
                statusLabel.setText("Game over");
            else {
                String descr = "";

                switch (game.turnPhase()) {
                case NONE:
                    descr = "Game not started";
                    break;

                case PURCHASE_UNITS:
                    descr = "Select units to purchase";
                    break;

                case MOVEMENTS:
                    descr = "Awaiting movements";
                    break;

                case MOBILIZE_UNITS:
                    descr = String.format("Place %s unit", purchasedUnitsBuffer.peek().name());
                    break;

                default:
                    break;
                }

                String playerName = game.currentPlayer().name();
                int money = game.currentPlayer().getMoney();
                statusLabel.setText(String.format("Player %s ($%d): %s", playerName, money, descr));
            }
        } else {
            statusLabel.setText("Please load a new game");
        }
    }

    private void updateUISensitivity() {
        Game game = appl.getGame();

        boolean gameStarted = (game != null);
        boolean gameOver = gameStarted && game.isOver();
        boolean inMovements = gameStarted && !gameOver && game.turnPhase() == TurnPhase.MOVEMENTS;
        boolean inMobilize = gameStarted && !gameOver && game.turnPhase() == TurnPhase.MOBILIZE_UNITS;

        boolean combatPending = (gameStarted &&
                                 !gameOver &&
                                 inMovements &&
                                 game.combatPending());

        endPhaseAction.setEnabled(gameStarted && !(combatPending || gameOver));
        startCombatAction.setEnabled(combatPending);
    }

    public void phaseChanged() {
        Game game = appl.getGame();
        
        updateUISensitivity();

        if (game.turnPhase() == TurnPhase.PURCHASE_UNITS) {
            updateStatus();
            UnitPurchaseDialog dialog = new UnitPurchaseDialog(this);
            dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            dialog.setVisible(true);
            game.purchaseUnits(dialog.purchasedUnits());
            dialog.dispose();
            game.endPhase();
        } else if (game.turnPhase() == TurnPhase.MOBILIZE_UNITS) {
            purchasedUnitsBuffer = new LinkedList<TerritoryUnit>(game.unitsToMobilize());
            if (purchasedUnitsBuffer.isEmpty())
                appl.getGame().endPhase();
        } else if (game.turnPhase() == TurnPhase.COLLECT_INCOME) {
            game.endPhase();
        }

        updateUISensitivity();
        updateStatus();
    }

    public void attackInitiated(Territory territory) {
        updateUISensitivity();
        updateStatus();
    }

    public void combatStarted(CombatSequence combatSequence) {
        CombatSequenceDialog dialog = new CombatSequenceDialog(this, combatSequence);
        dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        dialog.setVisible(true);
        appl.getGame().endCombat();
        updateUISensitivity();
        updateStatus();
    }

    public void gameOver() {
        updateUISensitivity();
        updateStatus();
    }

    public void territorySelected(Territory territory) {
        if (appl.getGame().turnPhase() == TurnPhase.MOBILIZE_UNITS) {
            TerritoryUnit unit = purchasedUnitsBuffer.peek();

            if (appl.getGame().canPlaceUnit(unit, territory)) {
                appl.getGame().mobilizeUnit(unit, territory);
                purchasedUnitsBuffer.poll();
            } else {
                JOptionPane.showMessageDialog(this,
                                              "Cannot place at the selected territory",
                                              "Invalid territory",
                                              JOptionPane.INFORMATION_MESSAGE);
            }
            
            if (purchasedUnitsBuffer.isEmpty())
                appl.getGame().endPhase();
            else
                updateStatus();
        }
    }
}

class CombatSequenceDialog extends JDialog
    implements CombatSequenceListener, ActionListener
{
    private CombatSequence combat;
    private JPanel topPane;
    private JPanel yBoxPane;
    private Map<String, JLabel> attackerUnitSummary;
    private Map<String, JLabel> defenderUnitSummary;
    private JLabel attackerOutcomeLabel;
    private JLabel defenderOutcomeLabel;
    private JButton actionButton;

    public CombatSequenceDialog(Frame appFrame, CombatSequence combat) {
        super(appFrame, "Combat", true);

        this.combat = combat;
        combat.addListener(this);

        attackerUnitSummary = new HashMap<String, JLabel>();
        defenderUnitSummary = new HashMap<String, JLabel>();

        topPane = new JPanel(new BorderLayout());

        yBoxPane = new JPanel();
        yBoxPane.setLayout(new BoxLayout(yBoxPane, BoxLayout.Y_AXIS));

        yBoxPane.add(createAttackerPane());
        yBoxPane.add(createDefenderPane());
        yBoxPane.add(createResultsPane());

        JPanel tmp = new JPanel(new GridLayout(1, 1));
        actionButton = new JButton();
        actionButton.addActionListener(this);
        tmp.add(actionButton);
        yBoxPane.add(tmp);

        topPane.add(yBoxPane, BorderLayout.CENTER);

        setSize(500, 400);

        add(topPane);

        update();
        updateUnitSummary();
    }

    private void update() {
        updateRoundResults();

        switch(combat.phase()) {
        case AWAITING_ATTACKER_FIRE:
        case AWAITING_DEFENDER_FIRE:
            updateUnitSummary();
            actionButton.setText("Attack/Defend");
            break;

        case AWAITING_ATTACKER_CASUALTIES_REMOVAL:
            actionButton.setText("Remove attacker casualties");
            updateUnitSummary();
            break;

        case AWAITING_DEFENDER_CASUALTIES_REMOVAL:
            actionButton.setText("Remove defender casualties");
            updateUnitSummary();
            break;

        case END_OF_ROUND:
            offerRetreat();
            break;

        case TERMINATED:
            setVisible(false);
            break;
        }
    }

    private void offerRetreat() {
        String msg = "Does the attacker want to retreat?";
        int result = JOptionPane.showConfirmDialog(null,
                                                   msg, msg,
                                                   JOptionPane.YES_NO_OPTION);
        if (result == 0)
            combat.retreat();
        else
            combat.startRound();
    }

    private void updateRoundResults() {
        switch(combat.phase()) {
        case AWAITING_ATTACKER_FIRE:
        case AWAITING_DEFENDER_FIRE:
            attackerOutcomeLabel.setText("");
            defenderOutcomeLabel.setText("");
            break;

        case AWAITING_ATTACKER_CASUALTIES_REMOVAL:
        case AWAITING_DEFENDER_CASUALTIES_REMOVAL:
            attackerOutcomeLabel.setText(Integer.toString(combat.attackerCasualties()));
            defenderOutcomeLabel.setText(Integer.toString(combat.defenderCasualties()));
            break;
        }
    }

    private void updateUnitSummary() {
        Map<String, Integer> map;

        Set<TerritoryUnit> attackers = combat.attackers();
        map = new HashMap<String, Integer>();
        for (TerritoryUnit unit : attackers) {
            if (map.containsKey(unit.name()))
                map.put(unit.name(), map.get(unit.name()) + 1);
            else
                map.put(unit.name(), 1);
        }
        for (String str : attackerUnitSummary.keySet()) {
            int count = 0;
            if (map.containsKey(str))
                count = map.get(str);
            attackerUnitSummary.get(str).setText(Integer.toString(count));
        }

        Set<TerritoryUnit> defenders = combat.defenders();
        map = new HashMap<String, Integer>();
        for (TerritoryUnit unit : defenders) {
            if (map.containsKey(unit.name()))
                map.put(unit.name(), map.get(unit.name()) + 1);
            else
                map.put(unit.name(), 1);
        }
        for (String str : defenderUnitSummary.keySet()) {
            int count = 0;
            if (map.containsKey(str))
                count = map.get(str);
            defenderUnitSummary.get(str).setText(Integer.toString(count));
        }

    }

    public void combatPhaseChanged() {
        update();
    }

    private JPanel createAttackerPane() {
        UnitPrototypeManager manager = UnitPrototypeManager.instance();

        GridLayout layout = new GridLayout(manager.prototypeKeys().size(), 2);
        JPanel attackerPane = new JPanel(layout);
        attackerPane.setBorder(BorderFactory.createTitledBorder("Attacker"));

        for (String prototypeName : manager) {
            attackerPane.add(new JLabel(prototypeName));
            attackerUnitSummary.put(prototypeName, new JLabel());
            attackerPane.add(attackerUnitSummary.get(prototypeName));
        }
        
        return attackerPane;
    }

    private JPanel createDefenderPane() {
        UnitPrototypeManager manager = UnitPrototypeManager.instance();

        GridLayout layout = new GridLayout(manager.prototypeKeys().size(), 2);
        JPanel defenderPane = new JPanel(layout);
        defenderPane.setBorder(BorderFactory.createTitledBorder("Defender"));

        for (String prototypeName : manager) {
            defenderPane.add(new JLabel(prototypeName));
            defenderUnitSummary.put(prototypeName, new JLabel());
            defenderPane.add(defenderUnitSummary.get(prototypeName));
        }
        
        return defenderPane;
    }

    private JPanel createResultsPane() {
        attackerOutcomeLabel = new JLabel();
        defenderOutcomeLabel = new JLabel();

        GridLayout layout = new GridLayout(2, 2);
        JPanel pane = new JPanel(layout);
        pane.setBorder(BorderFactory.createTitledBorder("Round Outcome"));

        pane.add(new JLabel("Defender casualties"));
        pane.add(defenderOutcomeLabel);
        pane.add(new JLabel("Attacker casualties"));
        pane.add(attackerOutcomeLabel);

        return pane;
    }

    public void actionPerformed(ActionEvent event) {
        switch(combat.phase()) {
        case AWAITING_ATTACKER_FIRE:
        case AWAITING_DEFENDER_FIRE:
            combat.attack();
            combat.defend();
            break;

        case AWAITING_ATTACKER_CASUALTIES_REMOVAL:
            selectAttackerCasualties(combat);
            break;

        case AWAITING_DEFENDER_CASUALTIES_REMOVAL:
            selectDefenderCasualties(combat);
            break;

        case TERMINATED:
            assert false;
            break;
        }
    }

    private void selectAttackerCasualties(CombatSequence cs) {
        Set<TerritoryUnit> attackers = cs.attackers();
        Set<TerritoryUnit> toRemove = new HashSet<TerritoryUnit>();

        int removed = 0;

        for (TerritoryUnit attacker : attackers) {
            if (removed >= cs.attackerCasualties() ||
                removed >= cs.attackers().size())
                break;

            removed++;
            toRemove.add(attacker);
        }

        cs.removeAttackerCasualties(toRemove);
    }

    private void selectDefenderCasualties(CombatSequence cs) {
        Set<TerritoryUnit> defenders = cs.defenders();
        Set<TerritoryUnit> toRemove = new HashSet<TerritoryUnit>();

        int removed = 0;

        for (TerritoryUnit defender : defenders) {
            if (removed >= cs.defenderCasualties() ||
                removed >= cs.defenders().size())
                break;

            removed++;
            toRemove.add(defender);
        }

        cs.removeDefenderCasualties(toRemove);
    }
}

class UnitPurchaseDialog extends JDialog implements ActionListener {
    private Appl appl;
    private Map<TerritoryUnit, Integer> shoppingList;
    private JLabel summaryLabel;

    public UnitPurchaseDialog(Frame appFrame) {
        super(appFrame, "Select units to purchase", true);

        appl = Appl.instance();

        shoppingList = new HashMap<TerritoryUnit, Integer>();

        JPanel topPanel = new JPanel(new BorderLayout());

        summaryLabel = new JLabel();
        updateSummary();
        topPanel.add(summaryLabel, BorderLayout.PAGE_START);

        topPanel.add(buildUnitList(), BorderLayout.CENTER);

        JButton acceptButton = new JButton("Accept");
        acceptButton.addActionListener(this);
        topPanel.add(acceptButton, BorderLayout.SOUTH);

        getContentPane().add(topPanel);

        setSize(400, 250);
    }

    private class SpinnerChangeListener implements ChangeListener {
        private TerritoryUnit unit;

        public SpinnerChangeListener(TerritoryUnit unit) {
            this.unit = unit;
        }

        public void stateChanged(ChangeEvent event) {
            JSpinner spinner = (JSpinner) event.getSource();

            Integer value = (Integer) spinner.getValue();
            int intValue = value.intValue();

            shoppingList.put(unit, intValue);

            if (intValue < 0)
                intValue = 0;

            while (spent() > available()) {
                intValue--;
                shoppingList.put(unit, intValue);
            }

            spinner.setValue(new Integer(intValue));

            updateSummary();
        }
    }

    private JPanel buildUnitList() {
        UnitPrototypeManager manager = appl.getPrototypeManager();
        int size = manager.prototypeKeys().size();

        JPanel panel = new JPanel(new GridLayout(size, 3));

        for (String id : manager) {
            panel.add(new JLabel(id));

            TerritoryUnit unit = manager.create(id);

            panel.add(new JLabel("$" + Integer.toString(unit.cost())));

            JSpinner spinner = new JSpinner();
            spinner.addChangeListener(new SpinnerChangeListener(unit));
            panel.add(spinner);
        }

        return panel;
    }

    private int available() {
        return appl.getGame().currentPlayer().getMoney();
    }

    private int spent() {
        int spent = 0;
        for (TerritoryUnit unit : shoppingList.keySet())
            spent += unit.cost() * shoppingList.get(unit);
        return spent;
    }

    private void updateSummary() {
        int remaining = available() - spent();
        summaryLabel.setText(String.format("Available: $%d of $%d", remaining, available()));
    }

    public Map<TerritoryUnit, Integer> purchasedUnits() {
        return new HashMap<TerritoryUnit, Integer>(shoppingList);
    }

    public void actionPerformed(ActionEvent event) {
        setVisible(false);
    }
}

public class Conquete {
    public static void main(String[] args) {
        try {
            SwingUtilities.invokeAndWait(new Runnable()
                {
                    public void run() {
                        ApplicationFrame f = new ApplicationFrame();
                        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        f.setVisible(true);
                    }
                });
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
