/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete.gui;

import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JComponent;

import conquete.*;

/**
 * A BoardView is a swing component that displays a Board.
 */
public class BoardView extends JComponent
    implements MouseListener, MouseMotionListener, TerritoryListener, GameListener {

    private static final int UNIT_ICON_WIDTH = 14;

    private class UnitCacheEntry {
        public int totalCount;
        public int activeCount;
        public Point position;
        public String id;
        public Territory territory;
    }

    private class TerritoryCacheEntry {
        public TerritoryCacheEntry() {
            unitPositionMap = new HashMap<String, UnitCacheEntry>();
        }

        public Map<String, UnitCacheEntry> unitPositionMap;
    }

    // new
    private Board board;
    private boolean dragInProgress = false;
    private Map<Territory, TerritoryCacheEntry> territoryInfoCache;
    private Appl appl;
    private List<BoardViewListener> listeners;
    private UnitRendererFactory unitRendererFactory;
    
    private boolean dragStarted = false;
    private TerritoryUnit draggedUnit = null;
    private Point draggedUnitPosition = new Point();

    public BoardView(Board board) {
        super();

        territoryInfoCache = new HashMap<Territory, TerritoryCacheEntry>();
        setBoard(board);

        enableEvents(AWTEvent.MOUSE_EVENT_MASK);
        addMouseListener(this);
        addMouseMotionListener(this);

        appl = Appl.instance();

        listeners = new LinkedList<BoardViewListener>();
        unitRendererFactory = new SimpleUnitRendererFactory();
    }

    public BoardView() {
        this(null);
    }

    public void addListener(BoardViewListener listener) {
        listeners.add(listener);
    }

    public void setBoard(Board board) {
        this.board = board;
        if (board != null) {
            for (Territory t : board)
                t.addListener(this);
            appl.getGame().addListener(this);
        }
        updateCache();
        revalidate();
        updateUI();
        repaint(getX(), getY(), getWidth(), getHeight());
    }

    public Dimension getPreferredSize() {
        if (board != null) {
            return new Dimension(board.width(), board.height());
        } else {
            return new Dimension(10, 10);
        }
    }

    public Dimension getMinimumSize() {
        return new Dimension(100, 100);
    }

    private Point getNamePosition(Polygon polygon) {
        int leftX = -1;
        int topY = -1;

        for (int x : polygon.xpoints)
            if (leftX == -1 || x < leftX)
                leftX = x;

        for (int y : polygon.ypoints)
            if (topY == -1 || y < topY)
                topY = y;

        return new Point(leftX + 3, topY + 12);
    }

    private void paintTerritory(Territory territory, Graphics2D g2d) {
        Graphics2D gc = (Graphics2D) g2d.create();
        if (territory.getOwner() != null)
            gc.setColor(territory.getOwner().color());
        else
            gc.setColor(Color.white);
        gc.fill(territory.outline());
        gc.setColor(Color.black);
        gc.draw(territory.outline());

        gc.setColor(new Color(.0f, .0f, .0f, .2f));
        Point point = getNamePosition(territory.outline());
        String label = String.format("%s (%d)", territory.name(), territory.income());
        gc.drawString(label, point.x, point.y);

        gc.dispose();
    }

    private class RenderUnitVisitor extends NullUnitVisitor {
        private Graphics2D graphics2d;
        private Rectangle outline;

        public RenderUnitVisitor(Graphics2D graphics2d, Rectangle outline) {
            this.graphics2d = graphics2d;
            this.outline = outline;
        }

        public Object forBomberAircraft(BomberAircraftUnit unit) {
            UnitRenderer r = unitRendererFactory.createBomberAircraftUnitRenderer();
            r.render(unit, graphics2d, outline);
            return null;
        }

        public Object forFighterAircraft(FighterAircraftUnit unit) {
            UnitRenderer r = unitRendererFactory.createFighterAircraftUnitRenderer();
            r.render(unit, graphics2d, outline);
            return null;
        }

        public Object forIndustry(IndustryUnit unit) {
            UnitRenderer r = unitRendererFactory.createIndustryUnitRenderer();
            r.render(unit, graphics2d, outline);
            return null;
        }

        public Object forInfantry(InfantryUnit unit) {
            UnitRenderer r = unitRendererFactory.createInfantryUnitRenderer();
            r.render(unit, graphics2d, outline);
            return null;
        }

        public Object forTank(TankUnit unit) {
            UnitRenderer r = unitRendererFactory.createTankUnitRenderer();
            r.render(unit, graphics2d, outline);
            return null;
        }
    }

    private void paintUnit(TerritoryUnit unit, Rectangle outline, Graphics2D graphics2d) {
        unit.accept(new RenderUnitVisitor(graphics2d, outline));
    }

    private void paintBoard(Graphics2D g2d, Rectangle viewRectangle) {
        Graphics2D tg = (Graphics2D) g2d.create();

        for (Territory territory : board) {
            paintTerritory(territory, g2d);

            TerritoryCacheEntry cache = territoryInfoCache.get(territory);
            for (String id : cache.unitPositionMap.keySet()) {
                UnitCacheEntry unitInfo = cache.unitPositionMap.get(id);
                Rectangle allocation = new Rectangle(unitInfo.position);
                allocation.width = UNIT_ICON_WIDTH;
                allocation.height = UNIT_ICON_WIDTH;
                TerritoryUnit unit = UnitPrototypeManager.instance().create(id);

                tg.setColor(Color.black);
                tg.drawString(Integer.toString(unitInfo.activeCount),
                              unitInfo.position.x, unitInfo.position.y - 3);
                paintUnit(unit, allocation, g2d);
                tg.drawString(Integer.toString(unitInfo.totalCount),
                              unitInfo.position.x, unitInfo.position.y + UNIT_ICON_WIDTH * 2);
            }
        }

        if (dragStarted) {
            Rectangle allocation = new Rectangle(draggedUnitPosition);
            allocation.width = UNIT_ICON_WIDTH;
            allocation.height = UNIT_ICON_WIDTH;
            paintUnit(draggedUnit, allocation, g2d);
        }

        tg.dispose();
    }

    protected void paintComponent(Graphics g) {
        if (board == null)
            return;

        Graphics gc = g.create();

        gc.setColor(Color.red);
        Graphics2D graphics2d = (Graphics2D) gc;
        graphics2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_ANTIALIASING,
                                                        RenderingHints.VALUE_ANTIALIAS_ON));
        paintBoard(graphics2d, null);

        gc.dispose();
    }

    private Point getLeftmostPoint(Polygon polygon) {
        int leftX = -1;
        int topY = -1, botY = -1;

        for (int x : polygon.xpoints)
            if (leftX == -1 || x < leftX)
                leftX = x;

        for (int y : polygon.ypoints)
            if (topY == -1 || y < topY)
                topY = y;

        for (int y : polygon.ypoints)
            if (botY == -1 || botY < y)
                botY = y;

        return new Point(leftX + 7, (botY + topY) / 2 - 10);
    }

    private void updateCache() {
        if (board == null) {
            territoryInfoCache.clear();
            return;
        }

        territoryInfoCache.clear();

        for (Territory territory : board) {
            TerritoryCacheEntry entry = new TerritoryCacheEntry();
            Point p = getLeftmostPoint(territory.outline());
            int shift = 0;
            for (TerritoryUnit unit : territory) {
                Game game = appl.getGame();
                boolean isActive = true;
                if (game.turnPhase() == TurnPhase.MOVEMENTS &&
                    game.currentPlayer() == unit.getOwner() &&
                    !game.unitIsActive(unit))
                    isActive = false;

                if (!entry.unitPositionMap.containsKey(unit.name())) {
                    Point up = new Point(p);
                    up.translate(shift, 0);
                    shift += UNIT_ICON_WIDTH + 5;
                    UnitCacheEntry unitInfo = new UnitCacheEntry();
                    unitInfo.id = unit.name();
                    unitInfo.territory = territory;
                    unitInfo.position = up;
                    unitInfo.totalCount = 1;
                    unitInfo.activeCount = isActive ? 1 : 0;
                    entry.unitPositionMap.put(unit.name(), unitInfo);
                } else {
                    UnitCacheEntry unitInfo = entry.unitPositionMap.get(unit.name());
                    unitInfo.totalCount += 1;
                    unitInfo.activeCount += isActive ? 1 : 0;
                }
            }
            territoryInfoCache.put(territory, entry);
        }
    }

    private Territory getTerritoryAt(int x, int y) {
        for (Territory territory : board)
            if (territory.outline().contains(x, y))
                return territory;

        return null;
    }

    private void startUnitDragMaybe(UnitCacheEntry unitInfo) {
        if (unitInfo.activeCount > 0) {
            for (TerritoryUnit unit : unitInfo.territory) {
                if (unit.name().equals(unitInfo.id)) {
                    dragStarted = true;
                    draggedUnit = unit;
                    break;
                }
            }
        }
    }

    private void handleMousePressedInMovements(MouseEvent event) {
        Game game = appl.getGame();

        int eventX = event.getX(), eventY = event.getY();

        Territory territory = getTerritoryAt(eventX, eventY);
        if (territory == null)
            return;

        if (territory.getOwner() == game.currentPlayer()) {
            TerritoryCacheEntry cache = territoryInfoCache.get(territory);

            for (String id : cache.unitPositionMap.keySet()) {
                UnitCacheEntry unitInfo = cache.unitPositionMap.get(id);
                Rectangle rectangle = new Rectangle(unitInfo.position);
                rectangle.width = UNIT_ICON_WIDTH;
                rectangle.height = UNIT_ICON_WIDTH;

                if (rectangle.contains(event.getX(), event.getY())) {
                    startUnitDragMaybe(unitInfo);
                }
            }
        }
    }

    // MouseListener iface

    public void mouseClicked(MouseEvent e) {
        if (board == null)
            return;

        if (appl.getGame().turnPhase() != TurnPhase.MOBILIZE_UNITS)
            return;

        Territory territory;
        if ((territory = getTerritoryAt(e.getX(), e.getY())) != null)
            for (BoardViewListener listener : listeners)
                listener.territorySelected(territory);
    }

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    public void mousePressed(MouseEvent event) {
        if (board == null)
            return;

        Game game = appl.getGame();

        if (game.turnPhase() == TurnPhase.MOVEMENTS)
            handleMousePressedInMovements(event);
    }

    public void mouseReleased(MouseEvent event) {
        if (!dragStarted)
            return;

        Territory territory = getTerritoryAt(event.getX(), event.getY());
        if (territory == null)
            return;

        Game game = appl.getGame();

        if (game.combatPending()) {
            if (draggedUnit.canAttack(territory)) {
                try {
                    game.addCombatUnit(draggedUnit);
                } catch (InvalidMoveException e) {
                    boolean notReached = false;
                    assert notReached;
                }
            }
        } else {
            if (draggedUnit.canMoveTo(territory) ||
                draggedUnit.canAttack(territory)) {
                UnitMovement movement = new UnitMovement(territory, draggedUnit);
                try {
                    game.executeMovement(movement);
                } catch (InvalidMoveException e) {
                    // shouldn't be here ...
                    assert false;
                }
            }
        }

        dragStarted = false;
        repaint();
    }

    // MouseMotionListener iface

    public void mouseDragged(MouseEvent e) {
        mouseMoved(e);
    }

    public void mouseMoved(MouseEvent e) {
        if (dragStarted) {
            draggedUnitPosition.x = e.getX();
            draggedUnitPosition.y = e.getY();
            repaint();
        }
    }

    // TerritoryListener iface

    public void stateChanged(Territory source) {
        updateCache();
        repaint();
    }

    // GameListener iface

    public void phaseChanged() {
        updateCache();
        repaint();
    }

    public void attackInitiated(Territory territory) {}

    public void combatStarted(CombatSequence combatSequence) {}

    public void gameOver() {}

}
