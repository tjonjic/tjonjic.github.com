/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

public class IndustryUnit extends StationaryUnit {

    private final static int COST = 15;

    public IndustryUnit(Player player) {
        super(player);
    }

    public IndustryUnit() {
        this(null);
    }

    public String name() {
        return "Industry";
    }

    public TerritoryUnit copy() {
        return new IndustryUnit(getOwner());
    }

    public boolean isDestroyable() {
        return false;
    }

    public int cost() {
        return COST;
    }

    public boolean hasAttackAbility() {
        return false;
    }

    public boolean hasDefenseAbility() {
        return false;
    }

    public int attackCapability() {
        throw new UnsupportedOperationException();
    }

    public int defenseCapability() {
        throw new UnsupportedOperationException();
    }

    public Object accept(UnitVisitor visitor) {
        return visitor.forIndustry(this);
    }

}
