/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete.tests;

import java.util.Set;
import java.util.HashSet;

import junit.framework.TestCase;

import conquete.*;

public class BoardTest extends TestCase {

    private Board board;
    private Territory territoryA;
    private Territory territoryB;
    private Territory territoryC;

    protected void setUp() {
        territoryA = new LandTerritory("A");
        territoryB = new LandTerritory("B");
        territoryC = new LandTerritory("C");

        Set<Territory> set = new HashSet<Territory>();
        set.add(territoryA);
        set.add(territoryB);
        set.add(territoryC);

        Set<Territory.Edge> edges = new HashSet<Territory.Edge>();
        edges.add(territoryA.edge(territoryB));
        edges.add(territoryB.edge(territoryC));

        board = new Board(set, edges);
    }

    public void testIteration() {
        for (Territory territory : board)
            assertEquals(territory == territoryA ||
                         territory == territoryB ||
                         territory == territoryC,
                         true);
    }

    public void testAdjacency1() {
        assertEquals(board.areAdjacent(territoryA, territoryB), true);
        assertEquals(board.areAdjacent(territoryA, territoryC), false);
        assertEquals(board.areAdjacent(territoryB, territoryC), true);
    }

    public void testAdjacency2() {
        Set<Territory> set = board.neighboursOf(territoryB);
        assertEquals(set.contains(territoryA), true);
        assertEquals(set.contains(territoryB), false);
        assertEquals(set.contains(territoryC), true);
    }

    public void testSearch() {
        assertEquals(board.findTerritory("A"), territoryA);
    }

}
