/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.Collection;
import java.util.Iterator;
import java.util.Collections;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedList;

import java.awt.Point;
import java.awt.Polygon;

/**
 * The base class for all <it>territories</it>.
 */
public abstract class Territory implements Iterable<TerritoryUnit> {

    /**
     * An edge between two territories.
     */
    public static class Edge {
        private Territory territory1;
        private Territory territory2;

        public Edge(Territory territory1, Territory territory2) {
            if (territory1 == territory2)
                throw new IllegalArgumentException("terriories cannot be equal");
            this.territory1 = territory1;
            this.territory2 = territory2;
        }

        public Territory territory1() {
            return territory1;
        }

        public Territory territory2() {
            return territory2;
        }

        public boolean equals(Object object) {
            return ((object != null) &&
                    (object instanceof Edge) &&
                    ((((Edge) object).territory1 == territory1 &&
                      ((Edge) object).territory2 == territory2) ||
                     (((Edge) object).territory1 == territory2 &&
                      ((Edge) object).territory2 == territory1)));
        }

        // Equal objects must have equal hash codes
        public int hashCode() {
            return territory1.hashCode() + territory2.hashCode();
        }
    }

    /** A human-friendly name for the territory; can be null */
    private String name;

    /** The units that are currently here */
    private Set<TerritoryUnit> units = new HashSet<TerritoryUnit>();

    /** The current owner, or null if it's no man's land */
    private Player owner = null;

    /** The outline */
    private Polygon outline = null;

    private Point center;

    /** The revenue the owner gains from the teritory */
    private int income;

    private List<TerritoryListener> listeners;

    public Territory(String name, int income, Polygon outline) {
        this.name = name;
        this.income = income;
        this.outline = outline;
        
        listeners = new LinkedList<TerritoryListener>();
    }

    public Territory(String name, int income) {
        this(name, income, null);
    }

    public Territory(String name, Polygon outline) {
        this(name, 0, outline);
    }

    public Territory(String name) {
        this(name, 0);
    }

    private void notifyListeners() {
        for (TerritoryListener listener : listeners)
            listener.stateChanged(this);
    }

    public void setOwner(Player owner) {
        this.owner = owner;
        notifyListeners();
    }

    public Player getOwner() {
        return owner;
    }

    public int income() {
        return income;
    }

    public Polygon outline() {
        return outline;
    }

    public void setCenter(int x, int y) {
        center = new Point(x, y);
    }

    public Point center() {
        return center;
    }

    public boolean isEmpty() {
        return units.isEmpty();
    }

    public boolean contains(TerritoryUnit unit) {
        return units.contains(unit);
    }

    public void place(TerritoryUnit unit) {
        units.add(unit);
        unit.setTerritory(this);
        notifyListeners();
    }

    public void remove(TerritoryUnit unit) {
        units.remove(unit);
        notifyListeners();
    }

    public void remove(Collection<TerritoryUnit> collection) {
        units.removeAll(collection);
        notifyListeners();
    }

    public Set<TerritoryUnit> units() {
        return Collections.unmodifiableSet(units);
    }

    public String name() {
        return name;
    }

    public Edge edge(Territory territory) {
        return new Edge(this, territory);
    }

    public void addListener(TerritoryListener listener) {
        listeners.add(listener);
    }

    public Iterator<TerritoryUnit> iterator() {
        return units.iterator();
    }

    public abstract Object accept(TerritoryVisitor visitor);

    public String toString() {
        return (super.toString() +
                String.format("[name=\"%s\",owner=%s,#units=%d]",
                              name(),
                              (getOwner() == null) ? "n/a" : "\"" + getOwner().name() + "\"",
                              units.size()));
    }
}
