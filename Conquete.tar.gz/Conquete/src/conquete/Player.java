/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.awt.Color;

public class Player {
    private String name;
    private int money;
    private Color color;

    public Player(String name, int money, Color color) {
        this.name = name;
        this.money = money;
        this.color = color;
    }

    public Player(String name) {
        this(name, 0, Color.black);
    }

    public String name() {
        return name;
    }

    public int getMoney() {
        return money;
    }

    public void subtractMoney(int amount) {
        setMoney(getMoney() - amount);
    }

    public void addMoney(int amount) {
        setMoney(getMoney() + amount);
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public Color color() {
        return color;
    }

    public String toString() {
        return super.toString() + String.format("[name=\"%s\"]", name());
    }
}
