/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.io.File;
import java.util.List;
import java.util.Map;

import java.awt.Polygon;

import conquete.parser.*;

/**
 * The application singleton class. Provides a convenient way to access
 * the global game related objects.
 */
public class Appl {
    private static final Appl INSTANCE = new Appl();

    private UnitPrototypeManager prototypeManager;
    private Board board;
    private List<Player> players;
    private Game game;

    private Appl() {
        prototypeManager = UnitPrototypeManager.instance();

        prototypeManager.installPrototype("Bomber Aircraft", new BomberAircraftUnit());
        prototypeManager.installPrototype("Fighter Aircraft", new FighterAircraftUnit());
        prototypeManager.installPrototype("Industry", new IndustryUnit());
        prototypeManager.installPrototype("Infantry", new InfantryUnit());
        prototypeManager.installPrototype("Tank", new TankUnit());
        //prototypeManager.installPrototype("Battleship", new BattleshipUnit());
        //prototypeManager.installPrototype("Transport Ship", new TransportShipUnit());

        board = null;
        players = null;
        game = null;
    }

    public static Appl instance() {
        return INSTANCE;
    }

    public UnitPrototypeManager getPrototypeManager() {
        return prototypeManager;
    }

    public Game newGame(Board board, List<Player> players) {
        this.board = board;
        this.players = players;
        return (game = new Game(board, players.toArray(new Player[0])));
    }

    public Game newGame(File file) throws InvalidBoardException {
        BoardParser parser = new BoardParser(file);
        board = parser.getBoard();
        players = parser.getPlayers();
        return (game = new Game(board, players.toArray(new Player[0])));
    }

    public Game getGame() {
        return game;
    }

    public Board getBoard() {
        return board;
    }

    public List<Player> getPlayers() {
        return players;
    }

}
