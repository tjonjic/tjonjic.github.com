/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.Collections;
import java.util.Set;
import java.util.HashSet;

/**
 * Represents a player's move.
 */
public class UnitMovement {

    /** The moved one */
    private TerritoryUnit unit;

    /** The destination of the movement */
    private Territory destination;

    public UnitMovement(Territory destination, TerritoryUnit unit) {
        if (destination == null || unit == null)
            throw new IllegalArgumentException();

        this.destination = destination;
        this.unit = unit;
    }

    public Territory destination() {
        return destination;
    }

    public TerritoryUnit unit() {
        return unit;
    }

}
