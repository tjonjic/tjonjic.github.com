/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

/**
 * Base class for all aicrafts.
 */
public abstract class AirUnit extends MobileUnit {

    public AirUnit(Player player) {
        super(player);
    }

    protected boolean canCrossTerritory(Territory territory) {
        return true;
    }

    protected boolean canEnterTerritory(Territory territory) {
        Object result = territory.accept(new TerritoryVisitor()
            {
                public Object forLandTerritory(LandTerritory territory) {
                    return Boolean.valueOf(territory.getOwner() == getOwner());
                }

                public Object forSeaTerritory(SeaTerritory territory) {
                    return Boolean.valueOf(false);
                }
            });
        return ((Boolean) result).booleanValue();
    }

    protected boolean canConductCombatIn(Territory territory) {
        return true;
    }

}
