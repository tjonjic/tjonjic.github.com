/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.Collections;
import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;

public class Game {

    private interface PhaseHandler {
        void startPhase();
        void buyUnits(Map<TerritoryUnit, Integer> prototypes);
        boolean currentPlayerHasMoves();
        boolean unitIsActive(TerritoryUnit unit);
        void executeMovement(UnitMovement movement) throws InvalidMoveException;
        boolean combatPending();
        void addCombatUnit(TerritoryUnit unit) throws InvalidMoveException;
        boolean combatStarted();
        void startCombat();
        CombatSequence getCombatSequence();
        void endCombat();
        Set<TerritoryUnit> unitsToMobilize();
        boolean canPlaceUnit(TerritoryUnit unit, Territory territory);
        void mobilizeUnit(TerritoryUnit unit, Territory territory);
        void endPhase();
    }

    private class BasicPhaseHandler implements PhaseHandler {
        public void startPhase() {
            throw new UnsupportedOperationException();
        }

        public void buyUnits(Map<TerritoryUnit, Integer> prototypes) {
            throw new UnsupportedOperationException();
        }

        public boolean currentPlayerHasMoves() {
            throw new UnsupportedOperationException();
        }

        public boolean unitIsActive(TerritoryUnit unit) {
            throw new UnsupportedOperationException();
        }

        public void executeMovement(UnitMovement movement) throws InvalidMoveException {
            throw new UnsupportedOperationException();
        }

        public boolean combatPending() {
            throw new UnsupportedOperationException();
        }

        public void addCombatUnit(TerritoryUnit unit) throws InvalidMoveException {
            throw new UnsupportedOperationException();
        }

        public boolean combatStarted() {
            throw new UnsupportedOperationException();
        }

        public void startCombat() {
            throw new UnsupportedOperationException();
        }

        public CombatSequence getCombatSequence() {
            throw new UnsupportedOperationException();
        }

        public void endCombat() {
            throw new UnsupportedOperationException();
        }

        public Set<TerritoryUnit> unitsToMobilize() {
            throw new UnsupportedOperationException();
        }

        public boolean canPlaceUnit(TerritoryUnit unit, Territory territory) {
            throw new UnsupportedOperationException();
        }

        public void mobilizeUnit(TerritoryUnit unit, Territory territory) {
            throw new UnsupportedOperationException();
        }

        public void endPhase() {
            throw new UnsupportedOperationException();
        }
    }

    private class NullPhaseHandler extends BasicPhaseHandler {}

    private class PurchaseUnitsPhaseHandler extends BasicPhaseHandler {
        public void startPhase() {
        }

        public void buyUnits(Map<TerritoryUnit, Integer> prototypes) {
            int total = 0;
            for (TerritoryUnit kind : prototypes.keySet())
                total += kind.cost() * prototypes.get(kind);

            if (total > currentPlayer().getMoney())
                throw new UnsupportedOperationException("overshopping :-)");

            for (TerritoryUnit kind : prototypes.keySet())
                for (int bought = 0; bought < prototypes.get(kind); ++bought) {
                    TerritoryUnit newBorn = kind.copy();
                    newBorn.setOwner(currentPlayer());
                    purchasedUnits.add(newBorn);
                }

            currentPlayer().subtractMoney(total);
        }

        public void endPhase() {
            setPhase(TurnPhase.MOVEMENTS);
        }
    }

    private class MovementsPhaseHandler extends BasicPhaseHandler {
        private Set<TerritoryUnit> activeSet = new HashSet<TerritoryUnit>();
        private boolean combatPending = false;
        private Set<TerritoryUnit> combatSet = new HashSet<TerritoryUnit>();
        private Territory combatTerritory;
        private boolean combatStarted = false;
        private CombatSequence combatSequence = null;

        public void startPhase() {
            activeSet.clear();
            combatPending = false;
            combatSet.clear();
            combatStarted = false;
            for (Territory territory : board)
                if (territory.getOwner() == currentPlayer())
                    for (TerritoryUnit unit : territory) {
                        if (unit.hasMovementAbility())
                            activeSet.add(unit);
                    }
        }

        public boolean currentPlayerHasMoves() {
            return activeSet.size() > 0;
        }

        public boolean unitIsActive(TerritoryUnit unit) {
            return activeSet.contains(unit);
        }

        private boolean movementTriggersCombat(UnitMovement movement) {
            return (movement.destination().getOwner() != null &&
                    movement.destination().getOwner() != currentPlayer() &&
                    movement.destination().units().size() > 0);
        }

        private boolean validMovement(UnitMovement movement) {
            return (movement.unit().getOwner() == currentPlayer() &&
                    activeSet.contains(movement.unit()) &&
                    movement.unit().hasMovementAbility());
        }

        private void executeNonCombatMovement(TerritoryUnit unit, Territory territory) {
            if (territory.getOwner() != currentPlayer())
                territory.setOwner(currentPlayer());
            
            unit.getTerritory().remove(unit);
            
            territory.place(unit);
        }

        public void executeMovement(UnitMovement movement)
            throws InvalidMoveException
        {
            if (combatPending || combatStarted)
                throw new UnsupportedOperationException();

            if (!validMovement(movement))
                throw new InvalidMoveException();

            TerritoryUnit unit = movement.unit();
            Territory destination = movement.destination();

            if (movementTriggersCombat(movement)) {
                if (unit.canAttack(destination)) {
                    combatPending = true;
                    combatTerritory = destination;
                    addCombatUnit(unit);
                } else
                    throw new InvalidMoveException();
            } else {
                if (unit.canMoveTo(destination)) {
                    activeSet.remove(unit);
                    executeNonCombatMovement(unit, destination);
                } else
                    throw new InvalidMoveException();
            }

            activeSet.remove(unit);

            if (combatPending)
                for (GameListener listener : listeners)
                    listener.attackInitiated(combatTerritory);
        }

        public void addCombatUnit(TerritoryUnit unit)
            throws InvalidMoveException
        {
            if (!combatPending())
                throw new UnsupportedOperationException();

            if (!unit.canAttack(combatTerritory))
                throw new InvalidMoveException();

            unit.getTerritory().remove(unit);

            combatSet.add(unit);
            activeSet.remove(unit);
        }

        public boolean combatPending() {
            return combatPending;
        }

        public boolean combatStarted() {
            return combatStarted;
        }

        public void startCombat() {
            if (combatPending()) {
                combatPending = false;
                combatStarted = true;
                combatSequence = new CombatSequence(combatTerritory);
                for (TerritoryUnit attacker : combatSet)
                    combatSequence.addAttacker(attacker);
                combatSequence.start();
                for (GameListener listener : listeners)
                    listener.combatStarted(combatSequence);
            } else
                throw new UnsupportedOperationException();
        }

        public CombatSequence getCombatSequence() {
            return combatSequence;
        }

        private void restoreUnit(TerritoryUnit unit) {
            unit.getTerritory().place(unit);
        }

        public void endCombat() {
            if (!combatStarted || !combatSequence.terminated())
                throw new UnsupportedOperationException();

            List<TerritoryUnit> casualties = new LinkedList<TerritoryUnit>();
            Set<TerritoryUnit> survivors = combatSequence.defenders();
            for (TerritoryUnit defender : combatTerritory)
                if (!survivors.contains(defender)) {
                    casualties.add(defender);
                }

            combatTerritory.remove(casualties);

            if (combatSequence.succeeded()) {
                for (TerritoryUnit attacker : combatSequence.attackers())
                    if (attacker.canConquer(combatTerritory))
                        combatTerritory.place(attacker);
                    else
                        restoreUnit(attacker);
                if (!combatTerritory.isEmpty())
                    combatTerritory.setOwner(currentPlayer());
            } else {
                for (TerritoryUnit unit : combatSequence.attackers())
                    restoreUnit(unit);
            }

            combatStarted = false;
        }

        public void endPhase() {
            boolean inCombat = combatStarted() && !combatSequence.terminated();
            if (combatPending || inCombat)
                throw new UnsupportedOperationException();

            setPhase(TurnPhase.MOBILIZE_UNITS);
        }
    }

    private class MobilizeUnitsPhaseHandler extends BasicPhaseHandler {
        public void startPhase() {
        }

        public Set<TerritoryUnit> unitsToMobilize() {
            return new HashSet<TerritoryUnit>(purchasedUnits);
        }

        public boolean canPlaceUnit(TerritoryUnit unit, Territory territory) {
            return placementPolicy.isValid(unit, territory);
        }

        public void mobilizeUnit(TerritoryUnit unit, Territory territory) {
            territory.place(unit);
            if (territory.getOwner() != unit.getOwner())
                territory.setOwner(unit.getOwner());
            purchasedUnits.remove(unit);
        }

        public void endPhase() {
            if (!purchasedUnits.isEmpty())
                purchasedUnits.clear();
            
            setPhase(TurnPhase.COLLECT_INCOME);
        }
    }

    private class CollectIncomePhaseHandler extends BasicPhaseHandler {
        public void startPhase() {
        }

        public void endPhase() {
            for (Territory territory : board)
                if (territory.getOwner() == currentPlayer())
                    currentPlayer().addMoney(territory.income());

            if (endgamePolicy.gameOver())
                isOver = true;
            else {
                turnNumber++;
                advanceToNextPlayer();
                setPhase(TurnPhase.PURCHASE_UNITS);
            }
        }
    }

    private PhaseHandler[] requestHandlers;
    private List<GameListener> listeners;
    private PlacementPolicy placementPolicy;
    private EndgamePolicy endgamePolicy;

    private Player[] players;
    private Board board;

    private boolean started;
    private boolean isOver;
    private int turnNumber;
    private TurnPhase turnPhase;
    private int currentPlayer;

    private HashSet<TerritoryUnit> purchasedUnits;

    public Game(Board board, Player[] players) {
        this.players = players;
        this.board = board;

        started = false;
        currentPlayer = 0;
        turnNumber = 0;
        turnPhase = TurnPhase.NONE;

        placementPolicy = new DefaultPlacementPolicy();
        endgamePolicy = new SimpleEndgamePolicy();

        requestHandlers = new PhaseHandler[] {
            new NullPhaseHandler(),
            new PurchaseUnitsPhaseHandler(),
            new MovementsPhaseHandler(),
            new MobilizeUnitsPhaseHandler(),
            new CollectIncomePhaseHandler()
        };

        listeners = new LinkedList<GameListener>();

        purchasedUnits = new HashSet<TerritoryUnit>();
    }

    private void advanceToNextPlayer() {
        currentPlayer = (currentPlayer + 1) % players.length;
    }

    private void setPhase(TurnPhase phase) {
        if (turnPhase != phase) {
            turnPhase = phase;
            requestHandlers[phase.ordinal()].startPhase();
            for (GameListener listener : listeners) {
                listener.phaseChanged();
            }
        }
    }

    // General (phase independent) requests

    public void addListener(GameListener listener) {
        listeners.add(listener);
    }

    public void start() {
        started = true;
        currentPlayer = 0;
        setPhase(TurnPhase.PURCHASE_UNITS);
    }

    public boolean started() {
        return started;
    }

    public Player currentPlayer() {
        return players[currentPlayer];
    }

    public int turn() {
        return turnNumber;
    }

    public TurnPhase turnPhase() {
        return turnPhase;
    }

    public boolean isOver() {
        return isOver;
    }

    // Phase sensitive requests

    public void endPhase() {
        requestHandlers[turnPhase.ordinal()].endPhase();
    }

    public void purchaseUnits(Map<TerritoryUnit, Integer> prototypes) {
        requestHandlers[turnPhase.ordinal()].buyUnits(prototypes);
    }

    public void purchaseUnit(TerritoryUnit prototype) {
        Map<TerritoryUnit, Integer> s = new HashMap<TerritoryUnit, Integer>();
        s.put(prototype, 1);
        purchaseUnits(s);
    }

    public boolean currentPlayerHasMoves() {
        return requestHandlers[turnPhase.ordinal()].currentPlayerHasMoves();
    }

    public boolean unitIsActive(TerritoryUnit unit) {
        return requestHandlers[turnPhase.ordinal()].unitIsActive(unit);
    }

    public Set<TerritoryUnit> unitsToMobilize() {
        return requestHandlers[turnPhase.ordinal()].unitsToMobilize();
    }

    public boolean canPlaceUnit(TerritoryUnit unit, Territory territory) {
        return requestHandlers[turnPhase.ordinal()].canPlaceUnit(unit, territory);
    }

    public void mobilizeUnit(TerritoryUnit unit, Territory territory) {
        requestHandlers[turnPhase.ordinal()].mobilizeUnit(unit, territory);
    }

    public void executeMovement(UnitMovement movement) throws InvalidMoveException {
        requestHandlers[turnPhase.ordinal()].executeMovement(movement);
    }

    public boolean combatPending() {
        return requestHandlers[turnPhase.ordinal()].combatPending();
    }

    public void addCombatUnit(TerritoryUnit unit) throws InvalidMoveException {
        requestHandlers[turnPhase.ordinal()].addCombatUnit(unit);        
    }

    public boolean combatStarted() {
        return requestHandlers[turnPhase.ordinal()].combatStarted();
    }

    public void startCombat() {
        requestHandlers[turnPhase.ordinal()].startCombat();
    }

    public CombatSequence getCombatSequence() {
        return requestHandlers[turnPhase.ordinal()].getCombatSequence();
    }

    public void endCombat() {
        requestHandlers[turnPhase.ordinal()].endCombat();
    }

}
