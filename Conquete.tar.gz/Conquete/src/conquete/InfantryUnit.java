/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

/**
 * A type representing an infantry unit.
 */
public class InfantryUnit extends LandUnit {

    private static final int MOVEMENT_CAPABILITY = 1;
    private final static int ATTACK_CAPABILITY = 1;
    private final static int DEFENSE_CAPABILITY = 2;

    private final static int COST = 3;

    public InfantryUnit(Player player) {
        super(player);
    }

    public InfantryUnit() {
        this(null);
    }

    public String name() {
        return "Infantry";
    }

    public TerritoryUnit copy() {
        return new InfantryUnit(getOwner());
    }

    public boolean isDestroyable() {
        return true;
    }

    public boolean canConquer(Territory territory) {
        return true;
    }

    public int cost() {
        return COST;
    }

    public boolean hasAttackAbility() {
        return true;
    }

    public boolean hasDefenseAbility() {
        return true;
    }

    public int movementCapability() {
        return MOVEMENT_CAPABILITY;
    }

    public int attackCapability() {
        return ATTACK_CAPABILITY;
    }

    public int defenseCapability() {
        return DEFENSE_CAPABILITY;
    }

    public Object accept(UnitVisitor visitor) {
        return visitor.forInfantry(this);
    }

}
