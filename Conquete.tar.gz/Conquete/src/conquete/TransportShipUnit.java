/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.Iterator;
import java.util.Set;
import java.util.Collections;
import java.util.HashSet;

public class TransportShipUnit extends SeaUnit implements TransportUnit {

    private static final int MOVEMENT_CAPABILITY = 1;
    private final static int ATTACK_CAPABILITY = 1;
    private final static int DEFENSE_CAPABILITY = 2;

    private final static int COST = 1;

    private final static int CAPACITY = 3;
    private final static int INFANTRY_WEIGHT = 1;
    private final static int TANK_WEIGHT = 2;

    private Set<TerritoryUnit> units;

    public TransportShipUnit(Player player) {
        super(player);
        units = new HashSet<TerritoryUnit>();
    }

    public TransportShipUnit() {
        this(null);
    }

    public void setTerritory(Territory territory) {
        super.setTerritory(territory);
        for (TerritoryUnit unit : units)
            unit.setTerritory(territory);
    }

    public String name() {
        return "Transport Ship";
    }

    public TerritoryUnit copy() {
        return new TransportShipUnit(getOwner());
    }

    public boolean isDestroyable() {
        return true;
    }

    public boolean canConquer(Territory territory) {
        return true;
    }

    public int cost() {
        return COST;
    }

    public boolean hasAttackAbility() {
        return true;
    }

    public boolean hasDefenseAbility() {
        return true;
    }

    public int movementCapability() {
        return MOVEMENT_CAPABILITY;
    }

    public int attackCapability() {
        return ATTACK_CAPABILITY;
    }

    public int defenseCapability() {
        return DEFENSE_CAPABILITY;
    }

    public Set<TerritoryUnit> units() {
        return Collections.unmodifiableSet(units);
    }

    private UnitVisitor unitWeightVisitor = new UnitVisitor() {
            public Object forBattleship(BattleshipUnit unit) {
                assert false;
                return null;
            }

            public Object forBomberAircraft(BomberAircraftUnit unit) {
                assert false;
                return null;
            }

            public Object forFighterAircraft(FighterAircraftUnit unit) {
                assert false;
                return null;
            }

            public Object forIndustry(IndustryUnit unit) {
                assert false;
                return null;
            }

            public Object forInfantry(InfantryUnit unit) {
                return new Integer(INFANTRY_WEIGHT);
            }

            public Object forTank(TankUnit unit) {
                return new Integer(TANK_WEIGHT);
            }

            public Object forTransportShip(TransportShipUnit unit) {
                assert false;
                return null;
            }
        };

    private UnitVisitor canHoldVisitor = new UnitVisitor() {
            public Object forBattleship(BattleshipUnit unit) {
                return Boolean.valueOf(false);
            }

            public Object forBomberAircraft(BomberAircraftUnit unit) {
                return Boolean.valueOf(false);
            }

            public Object forFighterAircraft(FighterAircraftUnit unit) {
                return Boolean.valueOf(false);
            }

            public Object forIndustry(IndustryUnit unit) {
                return Boolean.valueOf(false);
            }

            public Object forInfantry(InfantryUnit unit) {
                return Boolean.valueOf(true);
            }

            public Object forTank(TankUnit unit) {
                return Boolean.valueOf(true);
            }

            public Object forTransportShip(TransportShipUnit unit) {
                return Boolean.valueOf(false);
            }
        };

    public boolean canHold(TerritoryUnit passenger) {
        Object holds = passenger.accept(canHoldVisitor);
        if (!((Boolean) holds).booleanValue())
            return false;
        
        int fanout = 0;

        for (TerritoryUnit unit : units) {
            Integer weight = (Integer) unit.accept(unitWeightVisitor);
            fanout += weight.intValue();
        }

        Integer weight = (Integer) passenger.accept(unitWeightVisitor);
        fanout += weight.intValue();

        return fanout <= CAPACITY;
    }

    public void place(TerritoryUnit unit) {
        if (canHold(unit))
            units.add(unit);
        unit.setTerritory(getTerritory());
        unit.setParent(this);
    }

    public void remove(TerritoryUnit unit) {
        units.remove(unit);
    }

    public boolean canAdd(TerritoryUnit unit) {
        return canHold(unit);
    }

    public void add(TerritoryUnit unit) {
        place(unit);
    }

    public Object accept(UnitVisitor visitor) {
        return visitor.forTransportShip(this);
    }

    public Iterator<TerritoryUnit> iterator() {
        return units.iterator();
    }

}
