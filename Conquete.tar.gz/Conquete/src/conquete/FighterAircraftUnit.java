/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

public class FighterAircraftUnit extends AirUnit {

    private final static int MOVEMENT_CAPABILITY = 3;
    private final static int ATTACK_CAPABILITY = 3;
    private final static int DEFENSE_CAPABILITY = 4;

    private final static int COST = 8;
    
    public FighterAircraftUnit(Player player) {
        super(player);
    }

    public FighterAircraftUnit() {
        this(null);
    }

    public String name() {
        return "Fighter Aircraft";
    }

    public TerritoryUnit copy() {
        return new FighterAircraftUnit(getOwner());
    }

    public boolean isDestroyable() {
        return true;
    }

    public boolean canConquer(Territory territory) {
        return false;
    }

    public int cost() {
        return COST;
    }

    public int movementCapability() {
        return MOVEMENT_CAPABILITY;
    }

    public boolean hasAttackAbility() {
        return true;
    }

    public int attackCapability() {
        return ATTACK_CAPABILITY;
    }

    public boolean hasDefenseAbility() {
        return true;
    }

    public int defenseCapability() {
        return DEFENSE_CAPABILITY;
    }

    public Object accept(UnitVisitor visitor) {
        return visitor.forFighterAircraft(this);
    }

}
