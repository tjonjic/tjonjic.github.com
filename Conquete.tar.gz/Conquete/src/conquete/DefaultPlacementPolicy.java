/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

/**
 * A simple placement policy. A newly purchased unit can be placed
 * on a friendly teritory only, and all units except industry units
 * can only be placed if the latter already exists on it.
 */
public class DefaultPlacementPolicy implements PlacementPolicy {

    private class CanPlaceVisitor implements UnitVisitor {
        private Territory territory;

        public CanPlaceVisitor(Territory territory) {
            this.territory = territory;
        }

        public Object forBattleship(BattleshipUnit unit) {
            return Boolean.valueOf(false);
        }

        public Object forBomberAircraft(BomberAircraftUnit unit) {
            return test(unit);
        }

        public Object forFighterAircraft(FighterAircraftUnit unit) {
            return test(unit);
        }

        public Object forIndustry(IndustryUnit unit) {
            return Boolean.valueOf(territory.getOwner() == unit.getOwner());
        }

        public Object forInfantry(InfantryUnit unit) {
            return test(unit);
        }

        public Object forTank(TankUnit unit) {
            return test(unit);
        }

        public Object forTransportShip(TransportShipUnit unit) {
            return Boolean.valueOf(false);
        }

        private Boolean test(TerritoryUnit newUnit) {
            if (territory.getOwner() == newUnit.getOwner())
                for (TerritoryUnit unit : territory)
                    if (unit instanceof IndustryUnit)
                        return Boolean.valueOf(true);

            return Boolean.valueOf(false);
        }
    }

    public boolean isValid(TerritoryUnit unit, Territory territory) {
        Boolean result = (Boolean) unit.accept(new CanPlaceVisitor(territory));
        return result.booleanValue();
    }
}
