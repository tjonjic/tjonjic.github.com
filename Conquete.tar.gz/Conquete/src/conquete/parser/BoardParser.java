/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

// Quick n' dirty board parser

package conquete.parser;

import java.io.File;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;

import java.awt.Polygon;
import java.awt.Color;

import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.FactoryConfigurationError;  
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.DOMException;

import conquete.*;

public class BoardParser {
    private Document document;
    private LinkedList<Player> players;
    private Map<String, Player> playerTable;
    private Map<String, Territory> territoryTable;
    private Board board;

    public BoardParser(File file) throws InvalidBoardException {
        players = new LinkedList<Player>();
        territoryTable = new HashMap<String, Territory>();
        playerTable = new HashMap<String, Player>();

        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            document = builder.parse(file);
            readPlayers();
            readTerritories();
        } catch (Exception e) {
            e.printStackTrace();
            throw new InvalidBoardException();
        }
    }

    public List<Player> getPlayers() {
        return players;
    }

    public Board getBoard() {
        return board;
    }

    private Element getUniqueElement(String tagName) {
        return (Element) document.getDocumentElement().getElementsByTagName(tagName).item(0);
    }

    private void readPlayers() {
        Node listEl = getUniqueElement("player-list");

        NodeList list = listEl.getChildNodes();
        for (int i = 0; i < list.getLength(); i++)
            if (list.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) list.item(i);
                String name = element.getAttribute("name");
                int money = Integer.parseInt(element.getAttribute("money"));
                int colorSpec = Integer.parseInt(element.getAttribute("color"), 16);
                Player player = new Player(name, money, new Color(colorSpec));
                players.add(player);
                playerTable.put(name, player);
            }
    }

    private Territory createTerritory(Element territoryElement) {
        int income = Integer.parseInt(territoryElement.getAttribute("income"));
        Polygon outline = parseOutline(territoryElement.getAttribute("geometry"));
        String name = territoryElement.getAttribute("name");

        if (territoryElement.getAttribute("type").equals("land"))
            return new LandTerritory(name, income, outline);
        else
            return new SeaTerritory(name, income, outline);
    }

    private Set<Territory.Edge> buildEdges(NodeList territoryList)
        throws InvalidBoardException
    {
        Set<Territory.Edge> set = new HashSet<Territory.Edge>();

        for (int i = 0; i < territoryList.getLength(); i++) {
            if (territoryList.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element territoryEl = (Element) territoryList.item(i);
                Territory territory = territoryTable.get(territoryEl.getAttribute("id"));

                NodeList neListEl = territoryEl.getElementsByTagName("neighbour-list");
                for (int j = 0; j < neListEl.getLength(); j++) {
                    if (neListEl.item(j).getNodeType() == Node.ELEMENT_NODE) {
                        NodeList neList = neListEl.item(j).getChildNodes();

                        for (int k = 0; k < neList.getLength(); k++) {
                            if (neList.item(k).getNodeType() == Node.ELEMENT_NODE) {
                                Element e = (Element) neList.item(k);

                                String territoryId = e.getAttribute("id");
                                if (!territoryTable.containsKey(territoryId))
                                    throw new InvalidBoardException(String.format("missing territory id %s",
                                                                                  territoryId));

                                Territory neighbour = territoryTable.get(e.getAttribute("id"));
                                set.add(territory.edge(neighbour));
                            }                            
                        }
                    }
                }
            }
        }

        return set;
    }

    Polygon parseOutline(String str) {
        Polygon polygon = new Polygon();
        String[] points = str.split(";| ");
        for (int i = 0; i < points.length - 1; i += 2) {
            polygon.addPoint(Integer.parseInt(points[i]), Integer.parseInt(points[i+1]));
        }

        return polygon;
    }


    private void readTerritories() 
        throws InvalidBoardException
    {
        Node listEl = getUniqueElement("territory-list");

        NodeList list = listEl.getChildNodes();

        for (int i = 0; i < list.getLength(); i++)
            if (list.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) list.item(i);
                Territory territory = createTerritory(element);

                territory.setCenter(Integer.parseInt(element.getAttribute("centerx")),
                                    Integer.parseInt(element.getAttribute("centery")));
                
                territoryTable.put(element.getAttribute("id"), territory);
            }

        for (int i = 0; i < list.getLength(); i++)
            if (list.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element territoryEl = (Element) list.item(i);
                Territory territory = territoryTable.get(territoryEl.getAttribute("id"));

                NodeList ownerList = territoryEl.getElementsByTagName("owner");
                for (int j = 0; j < ownerList.getLength(); j++)
                    if (ownerList.item(j).getNodeType() == Node.ELEMENT_NODE) {
                        Element element = (Element) ownerList.item(j);
                        Player player = playerTable.get(element.getAttribute("player"));
                        territory.setOwner(player);

                        NodeList unitList = element.getChildNodes();
                        for (int k = 0; k < unitList.getLength(); k++) {
                            if (unitList.item(k).getNodeType() == Node.ELEMENT_NODE) {
                                Element unitEl = (Element) unitList.item(k);
                                int quantity = Integer.parseInt(unitEl.getAttribute("quantity"));
                                String type = unitEl.getAttribute("type");

                                UnitPrototypeManager manager = Appl.instance().getPrototypeManager();
                                for (int created = 0; created < quantity; created++) {
                                    TerritoryUnit unit = manager.create(type);
                                    unit.setOwner(player);
                                    territory.place(unit);
                                }
                            }
                        }
                    }
            }

        Set<Territory> set = new HashSet<Territory>();
        set.addAll(territoryTable.values());

        int boardWidth = Integer.parseInt(document.getDocumentElement().getAttribute("width"));
        int boardHeight = Integer.parseInt(document.getDocumentElement().getAttribute("height"));
        board = new Board(set, buildEdges(list), boardWidth, boardHeight);
    }
}
