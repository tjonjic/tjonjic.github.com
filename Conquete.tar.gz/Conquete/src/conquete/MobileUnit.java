/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.Set;
import java.util.HashSet;

/**
 * A class that defines common behavior for all units that have
 * movement capability.
 */
public abstract class MobileUnit extends TerritoryUnit {

    public MobileUnit(Player player) {
        super(player);
    }

    // template
    public final boolean canMoveTo(Territory territory) {
        int len;
        return (getTerritory() != null &&
                territory != getTerritory() &&
                canEnterTerritory(territory) &&
                (len = shortestPath(getTerritory(), territory)) != -1 &&
                len <= movementCapability());
    }

    // template
    public final boolean canAttack(Territory territory) {
        int len;
        return (getTerritory() != null &&
                territory != getTerritory() &&
                canConductCombatIn(territory) &&
                (len = shortestPath(getTerritory(), territory)) != -1 &&
                len <= movementCapability());
    }

    private int shortestPath(Territory source, Territory dest) {
        return shortestPathHelper(source, dest, new HashSet<Territory>());
    }

    private int shortestPathHelper(Territory source, Territory dest, Set<Territory> visited) {
        assert source != dest;

        Set<Territory> neighbours = Appl.instance().getBoard().neighboursOf(source);

        visited.add(source);

        if (neighbours.contains(dest))
            return 1;

        int shortest = -1;

        for (Territory t : neighbours)
            if (!visited.contains(t) && canCrossTerritory(t)) {
                int tmp = shortestPathHelper(t, dest, visited);
                if (shortest == -1 || (tmp != -1 && tmp < shortest))
                    shortest = tmp;
            }
        
        return (shortest == -1) ? shortest : shortest + 1;
    }

    public boolean hasMovementAbility() {
        return true;
    }

    /**
     * @return true if the unit can cross territory <code>territory</code>
     * during some movement.
     */
    protected abstract boolean canCrossTerritory(Territory territory);

    /**
     * @return true if the unit can enter the territory.
     */
    protected abstract boolean canEnterTerritory(Territory territory);

    // hook
    protected abstract boolean canConductCombatIn(Territory territory);

}
