/*
 * This file is part of Conquete.
 * 
 * Copyright (C) 2012 Tomislav Jonjic
 * 
 * Foobar is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Foobar is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

package conquete;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Collections;

/**
 * Creates instances of registered unit types.
 */
public class UnitPrototypeManager implements Iterable<String> {

    private static final UnitPrototypeManager INSTANCE = new UnitPrototypeManager();

    private HashMap<String, TerritoryUnit> prototypes;

    private UnitPrototypeManager() {
        prototypes = new HashMap<String, TerritoryUnit>();
    }

    public static UnitPrototypeManager instance() {
        return INSTANCE;
    }

    public void installPrototype(String key, TerritoryUnit prototype) {
        prototypes.put(key, prototype);
    }

    public TerritoryUnit create(String key) {
        return prototypes.get(key).copy();
    }

    public Set<String> prototypeKeys() {
        return Collections.unmodifiableSet(prototypes.keySet());
    }

    public Iterator<String> iterator() {
        return prototypes.keySet().iterator();
    }

}
